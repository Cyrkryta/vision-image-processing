The libraries we used are the following: SciPy, OpenCV, matplotlib.pyplot for visualisation & numpy 
Make sure that the lenna.jpg image is in the same folder as the jupyter notebook
